/**
 *
 *  @author Barcikowski Dominik S15375
 *
 */

package zad2;


public class Calc {
}  
